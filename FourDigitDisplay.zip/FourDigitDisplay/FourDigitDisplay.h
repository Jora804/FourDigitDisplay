#ifndef FOUR_DIGIT_DISPLAY_H
#define FOUR_DIGIT_DISPLAY_H

#include <Arduino.h>

class FourDigitDisplay {
public:
  FourDigitDisplay(
    int sga, int sgb, int sgc, int sgd, int sge, int sgf, int sgg, int sdp,
    int an0, int an1, int an2, int an3
  );

  void begin();                   // Инициализация пинов
  void showNumber(int left, int right);  // Отображение двух двузначных чисел
  void clear();                   // Очистка дисплея
  void showDot(int position);     // Отображение точки на заданной позиции (1–4)
  void update();                  // Основная функция мультиплексирования

private:
  int SGA, SGB, SGC, SGD, SGE, SGF, SGG, SDP;
  int AN0, AN1, AN2, AN3;
  int disp[5]; // Для хранения цифр
  int DIGITm, DIGITg;

  void nibble(int n);
  void dot(int d);
  void SGoff();
  void ANONOFF(int n);
  void decimal(int n);
  void decimal1(int n);
};

#endif
