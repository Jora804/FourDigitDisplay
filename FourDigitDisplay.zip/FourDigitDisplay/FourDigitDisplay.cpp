#include "FourDigitDisplay.h"

FourDigitDisplay::FourDigitDisplay(
  int sga, int sgb, int sgc, int sgd, int sge, int sgf, int sgg, int sdp,
  int an0, int an1, int an2, int an3
) {
  SGA = sga; SGB = sgb; SGC = sgc; SGD = sgd;
  SGE = sge; SGF = sgf; SGG = sgg; SDP = sdp;
  AN0 = an0; AN1 = an1; AN2 = an2; AN3 = an3;
}

void FourDigitDisplay::begin() {
  int pins[] = {SGA, SGB, SGC, SGD, SGE, SGF, SGG, SDP, AN0, AN1, AN2, AN3};
  for (int i = 0; i < 12; i++) pinMode(pins[i], OUTPUT);
  clear();
}

void FourDigitDisplay::clear() {
  digitalWrite(SGA, HIGH);
  digitalWrite(SGB, HIGH);
  digitalWrite(SGC, HIGH);
  digitalWrite(SGD, HIGH);
  digitalWrite(SGE, HIGH);
  digitalWrite(SGF, HIGH);
  digitalWrite(SGG, HIGH);
  digitalWrite(SDP, LOW);
  digitalWrite(AN0, LOW);
  digitalWrite(AN1, LOW);
  digitalWrite(AN2, LOW);
  digitalWrite(AN3, LOW);
}

void FourDigitDisplay::showNumber(int left, int right) {
  DIGITm = left;
  DIGITg = right;
}

void FourDigitDisplay::showDot(int position) {
  disp[4] = position;
}

void FourDigitDisplay::decimal(int n) {
  disp[1] = (int)(n / 10);
  disp[0] = n % 10;
}

void FourDigitDisplay::decimal1(int n) {
  disp[3] = (int)(n / 10);
  disp[2] = n % 10;
}

void FourDigitDisplay::nibble(int n) {
  switch(n) {
    case 0: digitalWrite(SGA,0); digitalWrite(SGB,0); digitalWrite(SGC,0); digitalWrite(SGD,0); digitalWrite(SGE,0); digitalWrite(SGF,0); digitalWrite(SGG,1); break;
    case 1: digitalWrite(SGA,1); digitalWrite(SGB,0); digitalWrite(SGC,0); digitalWrite(SGD,1); digitalWrite(SGE,1); digitalWrite(SGF,1); digitalWrite(SGG,1); break;
    case 2: digitalWrite(SGA,0); digitalWrite(SGB,0); digitalWrite(SGC,1); digitalWrite(SGD,0); digitalWrite(SGE,0); digitalWrite(SGF,1); digitalWrite(SGG,0); break;
    case 3: digitalWrite(SGA,0); digitalWrite(SGB,0); digitalWrite(SGC,0); digitalWrite(SGD,0); digitalWrite(SGE,1); digitalWrite(SGF,1); digitalWrite(SGG,0); break;
    case 4: digitalWrite(SGA,1); digitalWrite(SGB,0); digitalWrite(SGC,0); digitalWrite(SGD,1); digitalWrite(SGE,1); digitalWrite(SGF,0); digitalWrite(SGG,0); break;
    case 5: digitalWrite(SGA,0); digitalWrite(SGB,1); digitalWrite(SGC,0); digitalWrite(SGD,0); digitalWrite(SGE,1); digitalWrite(SGF,0); digitalWrite(SGG,0); break;
    case 6: digitalWrite(SGA,0); digitalWrite(SGB,1); digitalWrite(SGC,0); digitalWrite(SGD,0); digitalWrite(SGE,0); digitalWrite(SGF,0); digitalWrite(SGG,0); break;
    case 7: digitalWrite(SGA,0); digitalWrite(SGB,0); digitalWrite(SGC,0); digitalWrite(SGD,1); digitalWrite(SGE,1); digitalWrite(SGF,1); digitalWrite(SGG,1); break;
    case 8: digitalWrite(SGA,0); digitalWrite(SGB,0); digitalWrite(SGC,0); digitalWrite(SGD,0); digitalWrite(SGE,0); digitalWrite(SGF,0); digitalWrite(SGG,0); break;
    case 9: digitalWrite(SGA,0); digitalWrite(SGB,0); digitalWrite(SGC,0); digitalWrite(SGD,0); digitalWrite(SGE,1); digitalWrite(SGF,0); digitalWrite(SGG,0); break;
  }
}

void FourDigitDisplay::SGoff() {
  digitalWrite(SGA, HIGH);
  digitalWrite(SGB, HIGH);
  digitalWrite(SGC, HIGH);
  digitalWrite(SGD, HIGH);
  digitalWrite(SGE, HIGH);
  digitalWrite(SGF, HIGH);
  digitalWrite(SGG, HIGH);
  digitalWrite(SDP, LOW);
}

void FourDigitDisplay::ANONOFF(int n) {
  digitalWrite(AN0, LOW);
  digitalWrite(AN1, LOW);
  digitalWrite(AN2, LOW);
  digitalWrite(AN3, LOW);
  switch (n) {
    case 1: digitalWrite(AN1, HIGH); break;
    case 2: digitalWrite(AN0, HIGH); break;
    case 3: digitalWrite(AN3, HIGH); break;
    case 4: digitalWrite(AN2, HIGH); break;
  }
}

void FourDigitDisplay::update() {
  decimal(DIGITm);
  nibble(disp[1]); ANONOFF(1); delay(2); ANONOFF(0);
  nibble(disp[0]); ANONOFF(2); delay(2); ANONOFF(0);
  decimal1(DIGITg);
  nibble(disp[3]); ANONOFF(3); delay(2); ANONOFF(0);
  nibble(disp[2]); ANONOFF(4); delay(2); ANONOFF(0);
  SGoff();
}
